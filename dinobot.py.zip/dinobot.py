import pyautogui
import pyscreenshot as ImageGrab
from  PIL import ImageOps
import time
import numpy as np
class coordinates():
    replay = (960,540)
    dinosaur= (170,560)

def restartGame():
    pyautogui.click(coordinates.replay)
    

def jump():
    pyautogui.keyDown("space")
    time.sleep(.05)
    print("jump")
    pyautogui.keyUp("space")
def ig():
    box = (195,540,850,663)
    image = ImageGrab.grab(box)
    grayimg = ImageOps.grayscale(image)
    grayimg.save("gray.png")
    a = np.array(grayimg.getcolors())
    print(a.sum())
    return a.sum()
    
def main(clock):
    restartGame()
    while True:
        if (ig()==80812):
            print("no tree")
        else:
            time.sleep(.05)
            jump()
            time.sleep(0.09)
        clock+=1
clock=0            
main(clock)
