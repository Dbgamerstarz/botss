**********
Data types
**********

.. seealso:: :ref:`Data type objects <arrays.dtypes>`

.. automodule:: numpy.doc.basics
