.. _governance-people:

Current steering council and institutional partners
===================================================

Steering council
----------------

* Sebastian Berg

* Jaime Fernández del Río

* Ralf Gommers

* Charles Harris

* Nathaniel Smith

* Julian Taylor

* Pauli Virtanen

* Eric Wieser

* Marten van Kerkwijk

* Stephan Hoyer

* Allan Haldane

* Stefan van der Walt


Emeritus members
----------------

* Travis Oliphant - Project Founder / Emeritus Leader (served: 2005-2012)

* Alex Griffing (served: 2015-2017)


NumFOCUS Subcommittee
---------------------

* Chuck Harris

* Ralf Gommers

* Jaime Fernández del Río

* Nathaniel Smith

* External member: Thomas Caswell


Institutional Partners
----------------------

*  UC Berkeley (Stefan van der Walt)


Document history
----------------

https://github.com/numpy/numpy/commits/master/doc/source/dev/governance/governance.rst
